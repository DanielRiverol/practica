

const getUsers = async (req, res) => {
  let users = await userService.getAll();
  if (!users)
    return res
      .status(500)
      .send({
        status: "error",
        error: "Couldn't get users due to internal error",
      });
  res.send({ status: "success", payload: users });
};

const createUser = async (req, res) => {
  let { first_name, last_name, dni, email, birthDate, gender } = req.body;
  if (!first_name || !last_name || !dni || !email || !birthDate)
    return res
      .status(400)
      .send({ status: "error", error: "Incomplete values" });
  //Muy importante! La inserción actual de la fecha de nacimiento está pensada para hacerse en el formato MM - DD - YYYY. De otra forma, arrojará un error.
  let result = await userService.createUser({
    first_name,
    last_name,
    email,
    dni,
    birthDate,
    gender,
  });
  if (!result)
    return res.status(500).send({ status: "success", payload: result });
  res.send({ status: "success", payload: result });
};

const registerUserToCourse = async (req, res) => {
  //logica a implementar

  res.send({ status: "success", message: "User added to course" });
};

export default {
  getUsers,
  createUser,
  registerUserToCourse,
};
